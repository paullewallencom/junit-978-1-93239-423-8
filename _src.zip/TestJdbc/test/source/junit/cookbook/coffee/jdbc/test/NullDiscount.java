package junit.cookbook.coffee.jdbc.test;

import junit.cookbook.coffee.data.Discount;


public class NullDiscount extends Discount {

}
