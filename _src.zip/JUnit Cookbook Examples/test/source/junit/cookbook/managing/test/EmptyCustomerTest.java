/*
 * Created on Jun 12, 2003
 */
package junit.cookbook.managing.test;

import junit.cookbook.suites.test.CustomerTest;
import junit.framework.TestCase;

/**
 * @author jbrains
 */
public class EmptyCustomerTest
    extends TestCase
    implements CustomerTest {
        
}
