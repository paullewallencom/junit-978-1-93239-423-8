package junit.cookbook.coffee.display;

import junit.cookbook.coffee.model.CoffeeCatalog;


public class CoffeeShopView {
    private CoffeeCatalog catalog;

    public void setCatalog(CoffeeCatalog catalog) {
        this.catalog = catalog;
    }
}
