package junit.cookbook.coffee.model;

public class Customer {
    public String id;
    public String name;
    public String emailAddress;

    public Customer(String id) {
        this.id = id;
    }
}
