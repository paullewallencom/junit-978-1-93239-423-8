package junit.cookbook.essays;

import java.io.File;

public interface FileLister {
    File[] listFiles();
}
