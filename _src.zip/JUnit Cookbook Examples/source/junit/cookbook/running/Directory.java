package junit.cookbook.running;


public interface Directory {
    Object get(String name);
}
