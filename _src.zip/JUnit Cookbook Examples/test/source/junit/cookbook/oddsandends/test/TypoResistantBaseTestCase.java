package junit.cookbook.oddsandends.test;

import junit.framework.TestCase;

public class TypoResistantBaseTestCase extends TestCase {
    private final void setup() {
    }

    private final void teardown() {
    }
}
