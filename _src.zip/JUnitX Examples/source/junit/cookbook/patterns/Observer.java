package junit.cookbook.patterns;


public interface Observer {
    void update();
}

