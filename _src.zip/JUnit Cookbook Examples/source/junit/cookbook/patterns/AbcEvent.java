package junit.cookbook.patterns;

import java.util.EventObject;

public class AbcEvent {
    public AbcEvent() {
    }
}
