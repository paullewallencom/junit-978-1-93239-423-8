package junit.cookbook.util;


public interface BulletinBoard {
    void print(String partialMessage);
    void println(String entireMessage);
}
