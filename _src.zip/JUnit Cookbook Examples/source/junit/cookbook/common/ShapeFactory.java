/*
 * Created on May 3, 2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package junit.cookbook.common;

import junit.cookbook.common.test.SpyShapeMaker;

/**
 * @author jbrains
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ShapeFactory {

    public ShapeFactory() {
        
        // TODO Auto-generated constructor stub
    }

    public ShapeFactory(SpyShapeMaker spyShapeMaker) {
        
        // TODO Auto-generated constructor stub
    }

    public Shape makeShape(String string, double[] sideLengths) {
        // TODO Auto-generated method stub
        return null;
    }

}
