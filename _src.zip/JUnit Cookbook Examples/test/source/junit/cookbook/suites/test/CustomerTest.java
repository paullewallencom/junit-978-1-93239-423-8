package junit.cookbook.suites.test;
public interface CustomerTest {
}
