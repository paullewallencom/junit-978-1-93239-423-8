/*
 * Created on Jun 15, 2003
 */
package junit.cookbook.troubleshooting.test;

import junit.framework.TestCase;

/**
 * @author jbrains
 */
public class ManualTestSuiteCannotFindTest extends TestCase {
}
